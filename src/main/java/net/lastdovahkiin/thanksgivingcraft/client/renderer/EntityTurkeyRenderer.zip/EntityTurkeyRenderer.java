package net.lastdovahkiin.thanksgivingcraft.client.renderer;

import net.lastdovahkiin.thanksgivingcraft.Thanksgivingcraft;
import net.lastdovahkiin.thanksgivingcraft.entity.custom.EntityTurkey;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class EntityTurkeyRenderer extends LivingEntityRenderer<EntityTurkey, EntityTurkeyModel>
{
    private static final ResourceLocation TEXTURE = new ResourceLocation(Thanksgivingcraft.MOD_ID, "textures/entities/turkey.png");
    public EntityTurkeyRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new EntityTurkeyModel(), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(EntityTurkey entity) {
        return TEXTURE;
    }
}
